/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package flappy;

import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import java.applet.AudioClip;

/**
 *
 * @author
 * version 1.03 (ahora con la pelona incluida)
 */
public class FlappyMOD extends javax.swing.JFrame implements KeyListener {
    
    //variables
    private ImageIcon background;
    private ImageIcon baseImg;
    private ImageIcon flappyUp;
    private ImageIcon flappyMid;
    private ImageIcon pipeTop;
    private ImageIcon pipeBottom;
    private ImageIcon proyectil;
    private ImageIcon elmuelitas;
    private ImageIcon enemy;
    private ImageIcon waffles;
    private ImageIcon empty;
        
    AudioClip Sound;
    AudioClip Tiro;
    AudioClip Risa;
    private Timer timer; //hilo principal
    private int x = 100, y = 100; // posición inicial
    private int velocidadY = 0; // velocidad vertical
    private int gravedad = 1; // fuerza de gravedad
    private int salto = -8; // impulso hacia arriba
    private int suelo; // límite inferior del juego 
    private int puntuacion = 0;
    private boolean lanza=false;
    private int temp = 0;
    private int datorandom=200;
    private int vida = 100;
    private final int vidaFULL= 100;
    private boolean tieneVida = true;
    private boolean pressW= false;
    int contadorMuertes = 0;
    
    int proyectilX = 100;
    int enemyX = 600;
    //barras
    private int tuberiaX = 600;
    private int apertura = 130; // espacio entre tuberías
    private int anchoTuberia = 55;  
    
    private Random random = new Random();

    
    // Estado del juego
    private boolean juegoActivo = true;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FlappyMOD.class.getName());

    /**
     * Creates new form Flappy
     */
    
    public FlappyMOD() {
        initComponents();
        setSize(665, 650);
        setTitle("MuelasBird 1.03");
        addKeyListener(this);
        setFocusable(true);
        infodisparar.setText("PRESIONA \"W\" PARA DISPARAR MUELAS");
        
        Sound = java.applet.Applet.newAudioClip(getClass().getResource("/recursos/labelxd.wav"));
        Tiro = java.applet.Applet.newAudioClip(getClass().getResource("/recursos/disparo.wav"));
        Risa = java.applet.Applet.newAudioClip(getClass().getResource("/recursos/risa.wav"));
        
        background = new ImageIcon(this.getClass().getResource("/recursos/background.png"));
        pipeTop = new ImageIcon(getClass().getResource("/recursos/pipe-green-down.png"));
        pipeBottom = new ImageIcon(getClass().getResource("/recursos/pipe-green.png"));
        baseImg = new ImageIcon(this.getClass().getResource("/recursos/base.png"));
        flappyUp = new ImageIcon(this.getClass().getResource("/recursos/bluebird-upflap.png"));
        flappyMid = new ImageIcon(this.getClass().getResource("/recursos/bluebird-midflap.png"));
        proyectil = new ImageIcon(this.getClass().getResource("/recursos/pito.png"));
        elmuelitas = new ImageIcon(this.getClass().getResource("/recursos/spooky.png"));
        enemy = new ImageIcon(this.getClass().getResource("/recursos/faker.png"));
        waffles = new ImageIcon(this.getClass().getResource("/recursos/waffles.png"));
        empty = new ImageIcon(this.getClass().getResource("/recursos/empty.png"));
        
        fondo.setIcon(background);
        tuberiaAbajo.setIcon(pipeBottom);
        tuberiaArriba.setIcon(pipeTop);
        base.setIcon(baseImg);
        base1.setIcon(baseImg);
        sprite.setIcon(elmuelitas);
        jProyectil.setIcon(proyectil);
        enemigo.setIcon(enemy);
        jWaffles.setIcon(empty);
        //setbounds
        jProyectil.setBounds(jProyectil.getX(), jProyectil.getY(), proyectil.getIconWidth(), proyectil.getIconHeight()); //hitbox proyectil
        enemigo.setBounds(enemigo.getX(), enemigo.getY(), enemy.getIconWidth(), enemy.getIconHeight()); //hitbox enemigo
        sprite.setBounds(sprite.getX(), sprite.getY(), elmuelitas.getIconWidth(), elmuelitas.getIconHeight());
        base.setBounds(0, this.getHeight()-baseImg.getIconHeight(), baseImg.getIconWidth(), baseImg.getIconHeight());
        base1.setBounds(base.getWidth(), this.getHeight() - baseImg.getIconHeight(), baseImg.getIconWidth(), baseImg.getIconHeight());
        //tuberias inicialez
        int alturaApertura = 100 + random.nextInt(150);
        
        // Tubería superior (arriba, invertida)
        tuberiaArriba.setBounds(tuberiaX, alturaApertura - pipeTop.getIconHeight(),
        anchoTuberia, pipeTop.getIconHeight());
        // Tubería inferior (abajo, normal)
        tuberiaAbajo.setBounds(tuberiaX, alturaApertura + apertura, anchoTuberia,
        pipeBottom.getIconHeight());
        
        //limite inferior (suelo)
        suelo = this.getHeight() - baseImg.getIconHeight() - elmuelitas.getIconHeight();
        
        //mainloop
            Sound.stop();
            Sound.play();
        //timer para actualizar la posicion
            timer = new Timer(30, new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e){
                    aplicarGravedad();
                    moverTuberias();
                    moverEnemigo();
                    if(lanza==true){
                    moverProyectil();
                    }
                    detectarColision();
                }
            });
            timer.start();
    }  
    
    //funciones
    
    
    public void aplicarGravedad(){
        velocidadY += gravedad; // cada frame, gravedad aumenta la velocidad
        y += velocidadY; // nueva posición del sprite
                // Colisiones con el suelo y el techo
        if (y >= suelo) {
        y = suelo;
        velocidadY = 0; // detener en el suelo
        }
        if (y <= 0) {
        y = 0;

        velocidadY = 0; // detener en el techo
        }
        // Cambiar imagen según movimiento
        if (velocidadY < 0) {
        //sprite.setIcon(flappyMid);
        } else {
        //sprite.setIcon(flappyUp);
        }
        sprite.setLocation(x, y);
        jProyectil.setLocation(x+20, y+20);
        //System.out.println("Valor x " + x + "Valor y " + y + "suelo" + suelo);
    }
    
    public void resetGame(){
        enemigo.setIcon(enemy);
        tuberiaX = 600;
        enemyX = 600;
        vida=100;
        contadorMuertes = 0;
        y = 100;
        proyectilX = 100;
        lanza=false;
        velocidadY = 0;
        juegoActivo = true;
        timer.start();
        puntuacion = 0;
        infodisparar.setText("PRESIONA \"W\" PARA DISPARAR MUELAS");
        puntuacionlabel.setText("");
        jMuertes.setText("");
    }
    
    public void moverTuberias(){
        tuberiaX -= 5;
        
        if (tuberiaX + pipeTop.getIconWidth() < 0) {
        tuberiaX = getWidth();
        int alturaApertura = 80 + random.nextInt(150);
        tuberiaArriba.setBounds(tuberiaX, alturaApertura - pipeTop.getIconHeight(), anchoTuberia, pipeTop.getIconHeight());
        // Tubería inferior (abajo, normal)
        tuberiaAbajo.setBounds(tuberiaX, alturaApertura + apertura, anchoTuberia, pipeBottom.getIconHeight());
        } else {
        
        tuberiaArriba.setLocation(tuberiaX, tuberiaArriba.getY());
        tuberiaAbajo.setLocation(tuberiaX, tuberiaAbajo.getY());
        
        }
        
        //puntuacion
        if(tuberiaX == x){
            puntuacion += 1;
            String puntuacionTexto = String.valueOf(puntuacion);
            puntuacionlabel.setText(puntuacionTexto);
            //sonido risa waffles
            Risa.play();
            jWaffles.setIcon(waffles);
        }
        if(tuberiaX == x-80){
            jWaffles.setIcon(empty);
        }
    }
    
    public void moverProyectil(){
        proyectilX += 20;
        jProyectil.setLocation(proyectilX, temp+20);
        if(proyectilX>getWidth()){
            lanza=false;
            proyectilX = 100;
            pressW= false;
        }
        jProyectil.setBounds(jProyectil.getX(), jProyectil.getY(), proyectil.getIconWidth(), proyectil.getIconHeight()); //hitbox proyectil
    }
    
    private void moverEnemigo(){
            enemyX -= 1;
        if(tieneVida==false){ //muere enemigo
            enemyX = 600;
            datorandom = 80 + random.nextInt(200);
            enemigo.setLocation(enemyX, datorandom);
            tieneVida=true;
        } else{
            enemigo.setLocation(enemyX, datorandom);
        }
        enemigo.setBounds(enemigo.getX(), enemigo.getY(), enemy.getIconWidth(), enemy.getIconHeight()); //hitbox enemigo
    }
    
    public void detectarColision(){
        Rectangle rPajaro = sprite.getBounds();
        Rectangle rTuberiaArriba = tuberiaArriba.getBounds();
        Rectangle rTuberiaAbajo = tuberiaAbajo.getBounds();
        Rectangle rProyectil = jProyectil.getBounds();
        Rectangle rEnemigo = enemigo.getBounds();
        
        if (rPajaro.intersects(rTuberiaArriba) || rPajaro.intersects(rTuberiaAbajo)) { //colision pajaro y tuberias
            finDelJuego();
        }
        if(rProyectil.intersects(rEnemigo)){ //colision proyectil y enemigo
             damage();
        }
    }
    
    private void damage(){
        vida += -3;
        //realizar damage a el enemigo
        if(vida<100 && vida>75){
        }
        if(vida>50 && vida<75){
        }
        if(vida>27 && vida<50){
            vida += -3;
        }
        if(vida<27){ 
        }
        if(vida<=0){
            Sound.stop();
            Sound.play();
            tieneVida = false;
            contadorMuertes += 1;
            enemyX = 600;
            vida = vidaFULL; //reestablecer puntos de vida
            jMuertes.setText("Pelonas muertas: " + String.valueOf(contadorMuertes));
        }
        if(vida>=vidaFULL){ //vida completa
            enemigo.setIcon(enemy);
        }
    }
    private void finDelJuego() {
        juegoActivo = false;
        int opcion = JOptionPane.showConfirmDialog(this, "puntuacion: " + puntuacion + " " + "¿Volver a jugar?", "Game Over", JOptionPane.YES_NO_OPTION);
        timer.stop();
        //reiniciar?
        if(opcion == javax.swing.JOptionPane.YES_OPTION){
            resetGame();
        } else {
            System.exit(0);
        }
        //sonidos
        Tiro.stop();
        Sound.stop();
        Sound.play();
        Risa.stop();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        puntuacionlabel = new javax.swing.JLabel();
        jMuertes = new javax.swing.JLabel();
        jWaffles = new javax.swing.JLabel();
        infodisparar = new javax.swing.JLabel();
        enemigo = new javax.swing.JLabel();
        sprite = new javax.swing.JLabel();
        jProyectil = new javax.swing.JLabel();
        base = new javax.swing.JLabel();
        base1 = new javax.swing.JLabel();
        tuberiaArriba = new javax.swing.JLabel();
        tuberiaAbajo = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        puntuacionlabel.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        puntuacionlabel.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(puntuacionlabel);
        puntuacionlabel.setBounds(10, 10, 150, 30);

        jMuertes.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jMuertes.setForeground(new java.awt.Color(255, 0, 51));
        getContentPane().add(jMuertes);
        jMuertes.setBounds(40, 560, 360, 40);
        getContentPane().add(jWaffles);
        jWaffles.setBounds(290, 50, 120, 120);

        infodisparar.setBackground(new java.awt.Color(255, 255, 255));
        infodisparar.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        infodisparar.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(infodisparar);
        infodisparar.setBounds(280, 0, 400, 40);
        getContentPane().add(enemigo);
        enemigo.setBounds(440, 180, 40, 40);
        getContentPane().add(sprite);
        sprite.setBounds(160, 260, 110, 90);
        getContentPane().add(jProyectil);
        jProyectil.setBounds(100, 100, 50, 50);
        getContentPane().add(base);
        base.setBounds(330, 550, 665, 100);
        getContentPane().add(base1);
        base1.setBounds(0, 550, 665, 100);
        getContentPane().add(tuberiaArriba);
        tuberiaArriba.setBounds(500, 0, 55, 320);
        getContentPane().add(tuberiaAbajo);
        tuberiaAbajo.setBounds(500, 400, 55, 320);
        getContentPane().add(fondo);
        fondo.setBounds(0, 0, 665, 650);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //lineas del papu
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FlappyMOD().setVisible(true));
        
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel base;
    private javax.swing.JLabel base1;
    private javax.swing.JLabel enemigo;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel infodisparar;
    private javax.swing.JLabel jMuertes;
    private javax.swing.JLabel jProyectil;
    private javax.swing.JLabel jWaffles;
    private javax.swing.JLabel puntuacionlabel;
    private javax.swing.JLabel sprite;
    private javax.swing.JLabel tuberiaAbajo;
    private javax.swing.JLabel tuberiaArriba;
    // End of variables declaration//GEN-END:variables
    
    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
        velocidadY = salto; // aplicar impulso hacia arriba
        }
        if(e.getKeyChar() == 'w' | e.getKeyChar() == 'W'){
            //sonido
            lanza = true;
            if(pressW==false){
                Tiro.stop();
                Tiro.play();
                temp = y+3;
                pressW = true;
            }
            infodisparar.setText("");
        }
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
}
